package com.dnb.accountservice.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dnb.accountservice.dto.Transaction;

@Repository
public interface TransactionRepository extends CrudRepository<Transaction, String> {
}
