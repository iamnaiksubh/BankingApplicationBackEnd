package com.dnb.accountservice.exceptions;

public class InvalidIdException extends Exception{
	public InvalidIdException(String msg) {
		super(msg);
	}
}
