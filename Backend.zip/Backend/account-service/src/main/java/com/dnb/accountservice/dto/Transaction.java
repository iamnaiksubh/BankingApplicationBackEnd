package com.dnb.accountservice.dto;

import java.time.LocalDate;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dnb.accountservice.utils.CustomIdGenerator;
import com.dnb.accountservice.utils.StatusType;
import com.dnb.accountservice.utils.TransactionType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "transaction_seq")
	@GenericGenerator(name = "transaction_seq", strategy = "com.dnb.accountservice.utils.CustomIdGenerator",
	parameters = {@Parameter(name = CustomIdGenerator.INCREMENT_PARAM, value = "50"),
			@Parameter(name = CustomIdGenerator.VALUE_PREFIX_PARAMETER, value = "TID_"),
			@Parameter(name = CustomIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d")})
	public String transactionId;
	public String fromAccountId;
	public String toAccountId;
	public float amount;
	public LocalDate timeStamp = LocalDate.now();
	public StatusType status;
	public TransactionType transactionType;
}
