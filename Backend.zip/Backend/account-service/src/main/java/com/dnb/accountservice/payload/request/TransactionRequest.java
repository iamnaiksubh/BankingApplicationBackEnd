package com.dnb.accountservice.payload.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class TransactionRequest {
	@NotBlank
	public String fromAccountId;
	@NotBlank
	public String toAccountId;
	@NotBlank
	@Min(value = 1)
	public float amount;
}
