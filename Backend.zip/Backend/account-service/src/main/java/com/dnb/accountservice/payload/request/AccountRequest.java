package com.dnb.accountservice.payload.request;

import com.dnb.accountservice.utils.AccountType;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AccountRequest {
	@NotBlank(message = "inavalid user id")
	private	String userId;
	
	
	private AccountType accountType;
	private String accountStatus;

	@NotBlank(message = "invalid pan card number")
	private String pancardNumber;
	@NotBlank(message = "invalid aadhar card number")
	private String aadharcardNumber;
	@NotBlank(message = "mobile number must be 10 digit")
	@Column(length = 10)
	private String mobileNumber;
	@Min(value = 10000, message = "balance should more than 9999 RS")
	private float balance;
}
