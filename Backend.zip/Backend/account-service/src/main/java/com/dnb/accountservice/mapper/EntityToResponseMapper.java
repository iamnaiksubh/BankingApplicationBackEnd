package com.dnb.accountservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Transaction;
import com.dnb.accountservice.dto.WithdrawDeposit;
import com.dnb.accountservice.payload.request.TransactionRequest;
import com.dnb.accountservice.payload.response.AccountResponse;
import com.dnb.accountservice.payload.response.TransactionResponse;
import com.dnb.accountservice.payload.response.WithdrawDepositResponse;
import com.dnb.accountservice.utils.StatusType;
import com.dnb.accountservice.utils.TransactionType;

@Component
public class EntityToResponseMapper {
	public AccountResponse getAccountEntityToResponseObject(Account account) {

		AccountResponse accountResponse = new AccountResponse();

		accountResponse.setAadharcardNumber(account.getAadharcardNumber());
		accountResponse.setAccountId(account.getAccountId());
		accountResponse.setAccountType(account.getAccountType());
		accountResponse.setBalance(account.getBalance());
		accountResponse.setMobileNumber(account.getMobileNumber());
		accountResponse.setPancardNumber(account.getPancardNumber());
		accountResponse.setUserId(account.getUserId());

		return accountResponse;
	}

	public TransactionResponse getTransactionEntityToResponseObject(Transaction transaction) {

		TransactionResponse transactionResponse = new TransactionResponse();

		transactionResponse.setAmount(transaction.getAmount());
		transactionResponse.setFromAccountId(transaction.getFromAccountId());
		transactionResponse.setToAccountId(transaction.getToAccountId());
		transactionResponse.setStatus(transaction.getStatus());
		transactionResponse.setTimeStamp(transaction.getTimeStamp());
		transactionResponse.setTransactionType(transaction.getTransactionType());

		return transactionResponse;
	}
	
	public WithdrawDepositResponse getWithdrawDepositEntityToResponseObject(WithdrawDeposit withdrawDeposit) {
		
		WithdrawDepositResponse withdrawDepositResponse = new WithdrawDepositResponse();
		
		withdrawDepositResponse.setAccountId(withdrawDeposit.getAccountId());
		withdrawDepositResponse.setBalance(withdrawDeposit.getAmount());
		withdrawDepositResponse.setStatusType(StatusType.SUCCESS);
		withdrawDepositResponse.setTimeStamp(withdrawDeposit.getTimeStamp());
		
		return withdrawDepositResponse;
	}
}
