package com.dnb.accountservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientBalanceException;
import com.dnb.accountservice.exceptions.InvalidIdException;
import com.dnb.accountservice.mapper.RequestToEntityMapper;
import com.dnb.accountservice.payload.request.AccountRequest;
import com.dnb.accountservice.payload.request.TransactionRequest;
import com.dnb.accountservice.payload.request.WithdrawDepositRequest;
import com.dnb.accountservice.payload.response.AccountResponse;
import com.dnb.accountservice.payload.response.TransactionResponse;
import com.dnb.accountservice.payload.response.WithdrawDepositResponse;
import com.dnb.accountservice.service.AccountService;

import jakarta.ws.rs.core.Response;


@Controller
@RequestMapping("/api/account")
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	RequestToEntityMapper requestToEntityMapper;
	
	@PostMapping("/create")
	public ResponseEntity<?> createAccount(@RequestBody AccountRequest accountRequest) throws IdNotFoundException{
		try {
			Account account = requestToEntityMapper.getAccountRequestToEntityObject(accountRequest);
			AccountResponse accountResponse = accountService.createAccount(account);
			return new ResponseEntity(accountResponse, HttpStatus.CREATED);
		} catch (IdNotFoundException e) {
			throw new IdNotFoundException("User Id Not Founnd");
		}
	}
	
	@GetMapping("/{accountId}")
	public ResponseEntity<?> getAccountById(@PathVariable String accountId) throws IdNotFoundException{
		
		Optional<Account> account = accountService.getAccountById(accountId);
		
		if(account.isPresent())
			return ResponseEntity.ok(account);
		throw new IdNotFoundException("Account does not exist.");
	}  
	
	@GetMapping("/user/{userId}")
	public ResponseEntity<?> getAccountByUserId(@PathVariable String userId) throws IdNotFoundException{
		Iterable<Account> account = accountService.getAccountByUserId(Integer.parseInt(userId));
		Boolean notEmpty = account.iterator().hasNext();
		if(notEmpty)
			return ResponseEntity.ok(account);
		throw new IdNotFoundException("No account exist for user id " + userId);
	}
	
	@DeleteMapping("/{accountId}")
	public ResponseEntity<?> deleteAccountById(@PathVariable String accountId) throws InvalidIdException{
		if(accountService.deleteAccoutById(accountId)) {
			return ResponseEntity.ok("account deleted successfully");
		}else {
			throw new InvalidIdException("Invalid account id");
		}
	}
	
	@PostMapping("/transfer")
	public ResponseEntity<?> transferMoney(@RequestBody TransactionRequest transactionRequest) throws InvalidIdException, InsufficientBalanceException{
		try {
			TransactionResponse transactionResponse = accountService.transferMoney(requestToEntityMapper.getTransactionRequestToEntityObject(transactionRequest));
			return ResponseEntity.ok(transactionResponse);
		} catch (InsufficientBalanceException e) {
			throw new InsufficientBalanceException("Remaining balance should be more than 10000 RS");
		} catch (InvalidIdException e) {
			throw new InvalidIdException("Wrong account id...");
		}
	}
	
	@PostMapping("/withdraw")
	public ResponseEntity<?> withdrawMoney(@RequestBody WithdrawDepositRequest withdrawDepositRequest) throws IdNotFoundException, InsufficientBalanceException{
		
		try {
			WithdrawDepositResponse withDepositResponse =  accountService.withdrawMoney(requestToEntityMapper.getWithdrawDepositRequestToEntityMapper(withdrawDepositRequest));
			return ResponseEntity.ok(withDepositResponse);
		} catch (IdNotFoundException e) {
			throw new IdNotFoundException("Account Id Not Found...");
		} catch (InsufficientBalanceException e) {
			throw new InsufficientBalanceException("Insufficient Balance, remaining balance should be more than 9999 Rs");
		}
		
	}
	
	@PostMapping("/deposit")
	public ResponseEntity<?> depositeMoney(@RequestBody WithdrawDepositRequest withdrawDepositRequest) throws IdNotFoundException{
		
		try {
			WithdrawDepositResponse withDepositResponse =  accountService.depositMoney(requestToEntityMapper.getWithdrawDepositRequestToEntityMapper(withdrawDepositRequest));
			return ResponseEntity.ok(withDepositResponse);
		} catch (IdNotFoundException e) {
			throw new IdNotFoundException("Account Id Not Found...");
		}
		
	}
	
	
}
