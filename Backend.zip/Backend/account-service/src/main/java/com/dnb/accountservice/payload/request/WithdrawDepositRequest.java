package com.dnb.accountservice.payload.request;

import lombok.Data;

@Data
public class WithdrawDepositRequest {
	public String accountId;
	public float amount;
}
