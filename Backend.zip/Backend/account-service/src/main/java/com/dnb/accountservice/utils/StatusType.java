package com.dnb.accountservice.utils;

public enum StatusType {
	SUCCESS, FAILED, INSUFFICIENT_BALANCE;
}
