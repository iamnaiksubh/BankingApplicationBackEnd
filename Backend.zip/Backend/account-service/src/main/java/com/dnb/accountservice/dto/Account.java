package com.dnb.accountservice.dto;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dnb.accountservice.utils.AccountType;
import com.dnb.accountservice.utils.CustomIdGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "account_seq")
	@GenericGenerator(name = "account_seq", strategy = "com.dnb.accountservice.utils.CustomIdGenerator",
	parameters = {@Parameter(name = CustomIdGenerator.INCREMENT_PARAM, value = "50"),
			@Parameter(name = CustomIdGenerator.VALUE_PREFIX_PARAMETER, value = "AID_"),
			@Parameter(name = CustomIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d")})
	private String accountId;
	
	@Enumerated(EnumType.STRING)
	private AccountType accountType;
	private String accuntStatus;
	
	private	Integer userId;
	private String pancardNumber;
	private String aadharcardNumber;
	private String mobileNumber;
	private float balance;

}
