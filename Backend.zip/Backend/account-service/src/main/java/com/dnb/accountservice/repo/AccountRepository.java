package com.dnb.accountservice.repo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dnb.accountservice.dto.Account;

@Repository
public interface AccountRepository extends CrudRepository<Account, String> {
	public List<Account> findByUserId(Integer userId);

//	@Query("update Account e set e.balance = :amount where e.accountId = :accId")
//	public void updateBalance(@Param("amount") Float newBalance,@Param("accId") String accountId);
//
//	@Query("select e.balance from Account e where e.accountId = :accId")
//	public float getBalanceById(@Param("accId") String accountId);
}
