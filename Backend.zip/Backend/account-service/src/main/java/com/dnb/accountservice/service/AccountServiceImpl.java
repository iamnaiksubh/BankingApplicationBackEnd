package com.dnb.accountservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Transaction;
import com.dnb.accountservice.dto.User;
import com.dnb.accountservice.dto.WithdrawDeposit;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientBalanceException;
import com.dnb.accountservice.exceptions.InvalidIdException;
import com.dnb.accountservice.mapper.EntityToResponseMapper;
import com.dnb.accountservice.payload.response.AccountResponse;
import com.dnb.accountservice.payload.response.TransactionResponse;
import com.dnb.accountservice.payload.response.WithdrawDepositResponse;
import com.dnb.accountservice.repo.AccountRepository;
import com.dnb.accountservice.repo.TransactionRepository;
import com.dnb.accountservice.utils.StatusType;
import com.dnb.accountservice.utils.TransactionType;


@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	EntityToResponseMapper entityToResponseMapper;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Value("${api.auth}")
	private String URL;
	
	@Override
	public AccountResponse createAccount(Account account) throws IdNotFoundException {
		
		try {
			ResponseEntity<User> responseEntity = restTemplate.getForEntity(URL + "/" + account.getUserId(), User.class);
			accountRepository.save(account);
			
			return entityToResponseMapper.getAccountEntityToResponseObject(account);
		}catch(Exception e) {
			throw new IdNotFoundException("User Id Not Founnd");
		}
	}

	@Override
	public Optional<Account> getAccountById(String accountId) {
		Optional<Account> account = accountRepository.findById(accountId);
		
		if(account.isPresent())
			return Optional.of(account.get());
		
		return Optional.empty();
	}

	@Override
	public List<Account> getAccountByUserId(Integer userId) {
		return accountRepository.findByUserId(userId);
	}

	@Override
	public boolean deleteAccoutById(String accountId) {
		
		if(accountRepository.existsById(accountId)) {
			accountRepository.deleteById(accountId);
			
			if(!accountRepository.existsById(accountId))
				return true;
		}
		
		return false;
	}

	@Override
	public TransactionResponse transferMoney(Transaction transaction) throws InsufficientBalanceException, InvalidIdException {
		
		
		if(accountRepository.existsById(transaction.fromAccountId) && accountRepository.existsById(transaction.toAccountId)) {
			float amount = transaction.amount;
			// from user
			Account fromAccount = accountRepository.findById(transaction.getFromAccountId()).get();
			Account toAccount = accountRepository.findById(transaction.getToAccountId()).get();
			
			float fromUserBalance = fromAccount.getBalance();
			float fromUserRemainingBalance = fromUserBalance-amount;
			
			if(fromUserRemainingBalance >= 10000) {
				// to user
				
				float toUserBalance = toAccount.getBalance();
				float toUserUpdatedBalance =  toUserBalance + amount;
				
				// update balance
				fromAccount.setBalance(fromUserRemainingBalance);
				toAccount.setBalance(toUserUpdatedBalance);
				
				accountRepository.save(fromAccount);
				accountRepository.save(toAccount);
				
				 
				transaction.setStatus(StatusType.SUCCESS);
				transaction.setTransactionType(TransactionType.CREDIT);
				transactionRepository.save(transaction);
				
				return entityToResponseMapper.getTransactionEntityToResponseObject(transaction);
				
			}else {
				
				transaction.setStatus(StatusType.INSUFFICIENT_BALANCE);
				transaction.setTransactionType(TransactionType.CREDIT);
				transactionRepository.save(transaction);
				
				throw new InsufficientBalanceException("Remaining balance should be more than 10000 RS");
			}
		}else {
			transaction.setStatus(StatusType.FAILED);
			transaction.setTransactionType(TransactionType.CREDIT);
			transactionRepository.save(transaction);
			throw new InvalidIdException("Wrong account id...");
		}
		
	}

	@Override
	public WithdrawDepositResponse withdrawMoney(WithdrawDeposit withdrawDeposit)
			throws IdNotFoundException, InsufficientBalanceException {
		if(accountRepository.existsById(withdrawDeposit.accountId)) {
			Account account = accountRepository.findById(withdrawDeposit.accountId).get();
			float balance = account.getBalance() - withdrawDeposit.amount;
			
			if(balance >= 10000) {
				account.setBalance(balance);
				accountRepository.save(account);
				withdrawDeposit.setAmount(balance);
				return entityToResponseMapper.getWithdrawDepositEntityToResponseObject(withdrawDeposit);
			}else {
				throw new InsufficientBalanceException("Insufficient Balance, remaining balance should be more than 9999 Rs");
			}
		}else {
			throw new IdNotFoundException("Account Id Not Found...");
		}
	}

	@Override
	public WithdrawDepositResponse depositMoney(WithdrawDeposit withdrawDeposit) throws IdNotFoundException {
		if(accountRepository.existsById(withdrawDeposit.accountId)) {
			
			Account account = accountRepository.findById(withdrawDeposit.accountId).get();
			float balance = account.getBalance() + withdrawDeposit.amount;
			withdrawDeposit.setAmount(balance);
			account.setBalance(balance);
			accountRepository.save(account);
			return entityToResponseMapper.getWithdrawDepositEntityToResponseObject(withdrawDeposit);
			
		}else {
			throw new IdNotFoundException("Account Id Not Found...");
		}
	}

	
	

	

}
