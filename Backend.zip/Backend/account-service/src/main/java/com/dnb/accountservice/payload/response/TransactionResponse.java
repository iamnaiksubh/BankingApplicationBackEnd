package com.dnb.accountservice.payload.response;

import java.time.LocalDate;

import com.dnb.accountservice.utils.StatusType;
import com.dnb.accountservice.utils.TransactionType;

import lombok.Data;

@Data
public class TransactionResponse {
	public String fromAccountId;
	public String toAccountId;
	public float amount;
	public LocalDate timeStamp;
	public StatusType status;
	public TransactionType transactionType;
}
