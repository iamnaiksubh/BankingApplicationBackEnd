package com.dnb.accountservice.dto;

import java.time.LocalDate;

import com.dnb.accountservice.utils.StatusType;

import lombok.Data;

@Data
public class WithdrawDeposit {
	public String accountId;
	public float amount;
	public LocalDate timeStamp = LocalDate.now();
	public StatusType statusType;
}
