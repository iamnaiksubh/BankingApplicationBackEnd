package com.dnb.accountservice.utils;

public enum TransactionType {
	DEBIT, CREDIT
}
