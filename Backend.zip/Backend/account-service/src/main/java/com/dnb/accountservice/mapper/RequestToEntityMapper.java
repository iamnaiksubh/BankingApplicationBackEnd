package com.dnb.accountservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Transaction;
import com.dnb.accountservice.dto.WithdrawDeposit;
import com.dnb.accountservice.payload.request.AccountRequest;
import com.dnb.accountservice.payload.request.TransactionRequest;
import com.dnb.accountservice.payload.request.WithdrawDepositRequest;

@Component
public class RequestToEntityMapper {
	public Account getAccountRequestToEntityObject(AccountRequest accountRequest) {
		
		Account account = new Account();
		
		account.setUserId(Integer.parseInt(accountRequest.getUserId()));
		account.setAadharcardNumber(accountRequest.getAadharcardNumber());
		account.setAccountType(accountRequest.getAccountType());
		account.setAccuntStatus(accountRequest.getAccountStatus());
		account.setBalance(accountRequest.getBalance());
		account.setMobileNumber(accountRequest.getMobileNumber());
		account.setPancardNumber(accountRequest.getPancardNumber());
		
		return account;
	}
	
	public Transaction getTransactionRequestToEntityObject(TransactionRequest transactionRequest) {
		
		Transaction transaction = new Transaction();
		
		transaction.setAmount(transactionRequest.getAmount());
		transaction.setFromAccountId(transactionRequest.getFromAccountId());
		transaction.setToAccountId(transactionRequest.getToAccountId());
		
		return transaction;
	}
	
	public WithdrawDeposit getWithdrawDepositRequestToEntityMapper(WithdrawDepositRequest withdrawDepositRequest) {
		
		WithdrawDeposit withdrawDeposit = new WithdrawDeposit();
		
		withdrawDeposit.setAccountId(withdrawDepositRequest.getAccountId());
		withdrawDeposit.setAmount(withdrawDepositRequest.getAmount());
		
		return withdrawDeposit;
		
	}
}
