package com.dnb.accountservice.payload.response;

import java.time.LocalDate;

import com.dnb.accountservice.utils.StatusType;

import lombok.Data;

@Data
public class WithdrawDepositResponse {
	public String accountId;
	public float balance;
	public LocalDate timeStamp;
	public StatusType statusType;
}
