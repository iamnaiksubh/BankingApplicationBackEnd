package com.dnb.accountservice.payload.response;

import com.dnb.accountservice.utils.AccountType;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
public class AccountResponse {

	private String accountId;
	private	Integer userId;
	
	@Enumerated(EnumType.STRING)
	private AccountType accountType;

	private String pancardNumber;
	private String aadharcardNumber;
	private String mobileNumber;
	private float balance;
}
