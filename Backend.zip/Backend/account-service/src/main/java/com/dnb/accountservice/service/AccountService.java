package com.dnb.accountservice.service;

import java.util.List;
import java.util.Optional;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Transaction;
import com.dnb.accountservice.dto.WithdrawDeposit;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientBalanceException;
import com.dnb.accountservice.exceptions.InvalidIdException;
import com.dnb.accountservice.payload.response.AccountResponse;
import com.dnb.accountservice.payload.response.TransactionResponse;
import com.dnb.accountservice.payload.response.WithdrawDepositResponse;

public interface AccountService {
	public AccountResponse createAccount(Account account) throws IdNotFoundException;
	public WithdrawDepositResponse withdrawMoney(WithdrawDeposit withdrawDeposit) throws IdNotFoundException, InsufficientBalanceException;
	public WithdrawDepositResponse depositMoney(WithdrawDeposit withdrawDeposit) throws IdNotFoundException;
	public Optional<Account> getAccountById(String accountId);
	public List<Account> getAccountByUserId(Integer userId);
	public boolean deleteAccoutById(String accountId);
	public TransactionResponse transferMoney(Transaction transaction) throws InsufficientBalanceException, InvalidIdException;
}
