package com.dnb.accountservice.utils;

import org.springframework.stereotype.Component;

import lombok.NoArgsConstructor;

public enum AccountType {
	SAVING,CURRENT;	
}
