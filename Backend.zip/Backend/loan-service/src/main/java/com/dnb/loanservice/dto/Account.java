package com.dnb.loanservice.dto;

import com.dnb.loanservice.utils.AccountType;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;


@Data
public class Account {
	
	private String accountId;
	
	@Enumerated(EnumType.STRING)
	private AccountType accountType;
	private String accuntStatus;
	
	private	Integer userId;
	private String pancardNumber;
	private String aadharcardNumber;
	private String mobileNumber;
	private float balance;

}
