package com.dnb.loanservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.loanservice.dto.Loan;
import com.dnb.loanservice.payload.request.LoanRequest;

@Component
public class LoanRequestToEntity {
	
	public Loan getLoanEntity(LoanRequest loanRequest) {
		Loan loan = new Loan();
		loan.setLoanType(loanRequest.getLoanType());
		loan.setLoanAmount(loanRequest.getLoanAmount());
		loan.setAppliedDate(loanRequest.getAppliedDate());
		loan.setAccountId(loanRequest.getAccountId());
		
		return loan;
		
	}

}
