package com.dnb.loanservice.utils;

public enum AccountType {
	
	CURRENT,SAVINGS

}
