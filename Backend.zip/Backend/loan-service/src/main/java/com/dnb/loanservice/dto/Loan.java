package com.dnb.loanservice.dto;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dnb.loanservice.enums.LoanStatus;
import com.dnb.loanservice.enums.LoanType;
import com.dnb.loanservice.utils.CustomLoanIdGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Data
public class Loan {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "loan_seq")
	@GenericGenerator(name = "loan_seq", strategy = "com.dnb.loanservice.utils.CustomLoanIdGenerator",
	parameters = {@Parameter(name = CustomLoanIdGenerator.INCREMENT_PARAM, value = "1"),
	@Parameter(name = CustomLoanIdGenerator.VALUE_PREFIX_PARAMETER, value = "loan_"),
	@Parameter(name = CustomLoanIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d")})
	private String loanId;
	
	@Enumerated
	private LoanType loanType;
	
	private int loanAmount;
	
	@Enumerated
	private LoanStatus loanStatus = LoanStatus.PENDING;
	
	private String appliedDate;
	
	private String accountId;

}
