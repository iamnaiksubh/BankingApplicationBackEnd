package com.dnb.loanservice.payload.response;

import com.dnb.loanservice.enums.LoanStatus;
import com.dnb.loanservice.enums.LoanType;

import jakarta.persistence.Enumerated;
import lombok.Data;

@Data
public class LoanResponse {
private String loanId;
	
	@Enumerated
	private LoanType loanType;
	
	private int loanAmount;
	
	@Enumerated
	private LoanStatus loanStatus = LoanStatus.PENDING;
	
	private String appliedDate;
	
	private String accountId;
}
